# Imports

from tkinter import *
from tkinter import messagebox
import speedtest
# import time


# Welcome Text

# print("""__________         _________                        .______________              __   
# \______   \___.__./   _____/_____   ____   ____   __| _/\__    ___/___   _______/  |_ 
# |     ___<   |  |\_____  \\____ \_/ __ \_/ __ \ / __ |   |    |_/ __ \ /  ___/\   __/
# |    |    \___  |/        \  |_> >  ___/\  ___// /_/ |   |    |\  ___/ \___ \  |  |  
# |____|    / ____/_______  /   __/ \___  >\___  >____ |   |____| \___  >____  > |__|  
#           \/            \/|__|        \/     \/     \/              \/     \/        """)


# print("\nWelcome to PySpeedTest!")
# time.sleep(1)

# print("\nTesting your internet speed...")

# Speed Testing Internet Connection

# speed_test = speedtest.Speedtest()

# download_speed = speed_test.download()
# upload_speed = speed_test.upload()

# Print Out Speed Test Results

# rounded_dwn_speed = round(download_speed)
# rounded_upl_speed = round(upload_speed)

# print("\nYour Internet's Download Speed:",rounded_dwn_speed)
# print("Your Internet's Upload Speed:",rounded_upl_speed)

# Bye Text

# print("\nThanks for using PySpeedTest!")

# Functions

def run_test():

    try:
        speed_test = speedtest.Speedtest()

        download_speed = speed_test.download()
        upload_speed = speed_test.upload()

        rounded_dwn_speed = round(download_speed)
        rounded_upl_speed = round(upload_speed)

        output_list.insert(END, "Testing your internet speed...")
        output_list.insert(END, "")

        output_list.insert(END, "Your internet's download speed:",rounded_dwn_speed)
        output_list.insert(END, "Your internet's upload speed:",rounded_upl_speed)

        output_list.insert(END, "")

        output_list.insert(END, "Press 'Run Test' again to run the speedtest again.")
    
    except:
        messagebox.showerror("Error!", "Wi-Fi is turned off.")

def clear_lb():
    output_list.delete(0, 'end')

def exit_app():
    tk.destroy()

# GUI Version

tk = Tk()

tk.title("PySpeedTest")
tk.iconbitmap("C:/Users/proje/OneDrive/Desktop/PySpeedtest/app_icon.ico")
tk.geometry("500x300")

program_text = StringVar()

# Labels

welcome_text = Label(tk, text="Welcome to PySpeedtest!", font=('bold', 15), padx=20, pady=20)
welcome_text.grid(row=0, column=0)


# Buttons

test_button = Button(tk, text="Run Test", width=12, command=run_test)
test_button.grid(row=2, column=0, pady=10)

clear_lb = Button(tk, text="Clear Listbox", width=12, command=clear_lb)
clear_lb.grid(row=2, column=1, pady=10)

exit_program = Button(tk, text="Exit", width=12, command=exit_app)
exit_program.grid(row=3, column=3, pady=20)

# List Boxes

output_list = Listbox(tk, height=8, width=50, border=0)
output_list.grid(row=3, column=0, columnspan=3, rowspan=6, pady=10, padx=10)

# GUI Starter

tk.mainloop()